import React, { useEffect, useState } from "react";
import axios from 'axios';
import Getarticles from "./getarticles";


function Articles(){
    const [articlesList,SetarticlesList] = useState([]);
    useEffect(()=>{
        axios.get('http://localhost:8080/api/articles').then(res=>SetarticlesList(res.data)).catch((err)=>console.group(err))
    },[])
    
    var deleteTask = item =>{
        var newArticlesList = articlesList.filter(task=>!(task._id === item._id))
        SetarticlesList(newArticlesList)
    }

    var updateLikes = item =>{
        var newArticlesList = [...articlesList];
        newArticlesList.forEach(task=>{
            if(task._id === item._id){
            task.likes = item.likes
        }
        })
        SetarticlesList(newArticlesList)
    }
    
    console.log(articlesList)

    return (
        
        <div>
            <Getarticles articlesList={articlesList} deleteTask={deleteTask} updateLikes = {updateLikes}/>
        </div>
    )
}

export default Articles;