var mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
    author:String,
    title:String,
    message:String,
    pic:String,
    likes:{
        type:Number,
        default:0
    },
})

const Task = mongoose.model('article',TaskSchema);

module.exports = Task;