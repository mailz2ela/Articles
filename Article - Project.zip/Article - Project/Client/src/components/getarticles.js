import axios from "axios";
import React from "react";
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Getarticles(props){
    var individualArticle = props.articlesList.map((item,index)=>{

        var deleteArticle = (id)=>{
            axios.delete(`http://localhost:8080/api/articles/${id}`).then(res=>props.deleteTask(res.data)).catch(err=>console.log(err))
        }

        var updateLikes = (id)=>{
            axios.put(`http://localhost:8080/api/articles/${id}`,{
                
                likes:item.likes+1
            }).then(res=>props.updateLikes(res.data)).catch(err=>console.log(err))
        }
        
        return <li key={index}>
            <div>
                <Link to={{
                    pathname:`/article/${item._id}`
                }}><h2>{item.title}</h2></Link>
                <p>{item.message}</p>
                <h4>{item.author}</h4>
            </div>
            <div>
                <Link to= {{
                    pathname:`/editarticles/${item._id}`
                }}><button>Edit</button></Link><span>                   </span>
                <button onClick={()=>deleteArticle(item._id)}>Delete</button><span>                   </span>
                <button onClick={()=>updateLikes(item._id)}>Likes</button><span>   </span><span>{item.likes}</span>
            </div>
        </li>
    })
    return (
        <div>
            <ol type='none'>
                {individualArticle}
            </ol>
        </div>
    )
}

export default Getarticles;