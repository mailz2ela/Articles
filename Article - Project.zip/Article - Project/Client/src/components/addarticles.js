import axios from "axios";
import React, { useState } from "react";
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Addarticles(){
    const [author,Setauthor] = useState('')
    const [title,Settitle] = useState('')
    const [message,Setmessage] = useState('')

    var mySubmit = (e)=>{
        e.preventDefault()
        axios.post('http://localhost:8080/api/articles',{
            author:author,
            title:title,
            message:message
        }).then(res=>{
            Setauthor('')
            Setmessage('')
            Settitle('')
            alert('Article Posted Successfully')
    }).catch(err=>console.log(err))
    }
    return (
        <div>
            <form autoComplete='off' onSubmit={mySubmit}>
                <h2>Add New Article!</h2>
                <div>
                    <input type='text' placeholder='Author Name' value={author} onChange={(event)=>{Setauthor(event.target.value)}}></input>
                </div>
                <div>
                    <input type='text' placeholder='Title of Article' value={title} onChange={(event)=>{Settitle(event.target.value)}}></input>
                </div>
                <div>
                    <input type='text' placeholder='Message' value={message} onChange={(event)=>{Setmessage(event.target.value)}}></input>
                </div>
                <div>
                    <button type='submit'>Submit</button><span>      </span>
                    <Link to='/'><button>Home</button></Link>
                </div>

            </form>
            
        </div>
    )
}

export default Addarticles;