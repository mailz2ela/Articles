var mongoose = require('mongoose');
var url = 'mongodb://localhost:27017/CRUD';

module.exports = mongoose.connect(url,function(err){
    if(err)console.log(err)
    console.log('Database connected Successfully!')
})