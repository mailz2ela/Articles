import React, { useEffect, useState } from "react";
import axios from 'axios'
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Article(props){
    const [author,Setauthor] = useState('')
    const [title,Settitle] = useState('')
    const [message,Setmessage] = useState('')

    useEffect(()=>{
        axios.get(`http://localhost:8080/api/articles/${props.match.params.id}`).then(res=>{
            Setauthor(res.data.author)
            Settitle(res.data.title)
            Setmessage(res.data.message)
        }).catch(err=>console.log(err))
    },[])
    return (
        <div>
        <div>
            <h2>{title}</h2>
            <p>{message}</p>
            <h3>{author}</h3>
        </div>
        <div>
        <Link to='/'><button>Back to Home</button></Link>
        </div>
        </div>
    )
}

export default Article;