import React from "react";
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Navbar(){
    return (
        <div>
            <p><Link to='/'>Home</Link></p>
            <p><Link to='/addarticles'>Add Article</Link></p>
        </div>
    )
}

export default Navbar;