var express = require('express')
var app = express();
var router = require('../server/routes/routes')
var cors = require('cors')
require('../server/model/db')


app.use(express.json())
app.use(cors())
app.use('/api/articles',router)

app.listen(8080,function(err){
    if(err)console.log(err)
    console.log('Server Started at port : 8080')
})