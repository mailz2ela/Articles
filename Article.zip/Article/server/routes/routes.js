var express = require('express');
var router = express.Router();
var Task = require('../model/model');
var multer = require('multer');



const storage = multer.diskStorage({
    destination:(req,file,callback)=>{
        callback(null, '../client/public/uploads/')
    },
    filename:(req,file,callback)=>{
        callback(null, file.originalname)
    }
})

const upload = multer({storage:storage})

router.get('/',function(req,res){
    Task.find((err,docs)=>{
        if(err)console.log(err)
        res.json(docs)
    })
})

router.post('/',upload.single("pic"), function(req,res){
    const task = new Task(
        {
        author:req.body.author,
        title:req.body.title,
        message:req.body.message,
        pic:req.file.originalname,      
        
    })
    // req.body
    
    task.save((err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
        
    })
})

router.delete('/:id',function(req,res){
    Task.findByIdAndDelete(req.params.id,(err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
    })
})

router.get('/:id',function(req,res){
    Task.findById(req.params.id,(err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
    })
})

router.put('/:id', upload.single('pic'), function(req,res){

    Task.findByIdAndUpdate(req.params.id,
        {
            likes:req.body.likes,
            title:req.body.title,
            author:req.body.author,            
            message:req.body.message,
            pic:req.file.originalname
        },    
    {new:true},(err,doc)=>{
        if(err)console.log(err)
        res.json(doc)
    })    
})
    

module.exports = router;