import Header from './components/header';
import Navbar from './components/navbar';
import Articles from './components/articles';
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';
import Addarticles from './components/addarticles';
import Editarticles from './components/editarticles';
import React, { useEffect, useState } from "react";
import axios from 'axios';
import Article from './components/article';



function App(){
  const [articlesList,SetarticlesList] = useState([]);
  useEffect(()=>{
      axios.get('http://localhost:8080/api/articles').then(res=>SetarticlesList(res.data)).catch((err)=>console.group(err))
  },[])  

  

  return (
    <div>
      <Header />
      <Navbar />
      <Route exact path='/' render={()=><Articles />}></Route>
      <Route path='/article/:id' render={(props)=><Article {...props} articlesList={articlesList}/>}></Route>      
      <Route path='/editarticles/:id' render={(props)=><Editarticles {...props} />}></Route>
      <Route path='/addarticles' component={Addarticles}></Route>      
    </div>
  )
}

export default App;