import axios from "axios";
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Editarticles(props){
    const [author,Setauthor] = useState('')
    const [title,Settitle] = useState('')
    const [message,Setmessage] = useState('')
    const [pic,Setpic] = useState('')

    useEffect(()=>{
        axios.get(`http://localhost:8080/api/articles/${props.match.params.id}`).then(res=>{
            Setauthor(res.data.author)
            Settitle(res.data.title)
            Setmessage(res.data.message)
            Setpic(res.data.pic)
            
        }).catch(err=>console.log(err))
    },[]);
    
    var myUpdate = (e) => {
        
        e.preventDefault();

        const formData = new FormData();
        formData.append('author',author);
        formData.append('title',title);
        formData.append('message',message);
        formData.append('pic', pic);
        console.log(formData)
        axios.put(`http://localhost:8080/api/articles/${props.match.params.id}`,
        formData
        ).then(res=>{
        alert('Data updated successfully')
        
        console.log(res.data)
    }).catch(err=>console.log(err))
  }

      

    return (
        <div>
            <form autoComplete='off' onSubmit={myUpdate} encType='multipart/form-data'>
                <h2>Update Article!</h2>
                <div>
                    <input type='text' placeholder='Author Name' value={author} onChange={(event)=>{Setauthor(event.target.value)}} ></input>
                </div>
                <div>
                    <input type='text' placeholder='Title of Article' value={title} onChange={(event)=>{Settitle(event.target.value)}} ></input>
                </div>
                <div>
                    <input type='text' placeholder='Message' value={message} onChange={(event)=>{Setmessage(event.target.value)}} ></input>
                </div>
                <div>
                    <input type='file' name='pic' onChange={(event)=>{Setpic(event.target.files[0])}}></input>
                </div>
                <div>
                <button type='submit'>Update</button><span>      </span>
                    <Link to='/'><button>Home</button></Link>
                </div>
                </form>

        </div>
    )
}

export default Editarticles;