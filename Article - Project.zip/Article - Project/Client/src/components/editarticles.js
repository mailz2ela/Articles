import axios from "axios";
import React, { useEffect, useState } from "react";
import { BrowserRouter as Router, Route, Link, NavLink, Switch } from 'react-router-dom';

function Editarticles(props){
    var [author,Setauthor] = useState('')
    var [title,Settitle] = useState('')
    var [message,Setmessage] = useState('')

    useEffect(()=>{
        axios.get(`http://localhost:8080/api/articles/${props.match.params.id}`).then(res=>{
            Setauthor(res.data.author)
            Settitle(res.data.title)
            Setmessage(res.data.message)
        }).catch(err=>console.log(err))
    },[]);

    var myUpdate = () => {
        axios.put(`http://localhost:8080/api/articles/${props.match.params.id}`,{
            title:title,
            author:author,
            message:message
    }).then(res=>{
        alert('Data updated successfully')
        console.log(res.data)
    }).catch(err=>console.log(err))
    }
    
    console.log(author)

    return (
        <div>
            <form autoComplete='off' onSubmit={myUpdate} >
                <h2>Update Article!</h2>
                <div>
                    <input type='text' placeholder='Author Name' value={author} onChange={(event)=>{Setauthor(event.target.value)}} ></input>
                </div>
                <div>
                    <input type='text' placeholder='Title of Article' value={title} onChange={event=>Settitle(event.target.value)} ></input>
                </div>
                <div>
                    <input type='text' placeholder='Message' value={message} onChange={event=>Setmessage(event.target.value)} ></input>
                </div>
                <div>
                <button type='submit'>Update</button><span>      </span>
                    <Link to='/'><button>Home</button></Link>
                </div>
                </form>

        </div>
    )
}

export default Editarticles;